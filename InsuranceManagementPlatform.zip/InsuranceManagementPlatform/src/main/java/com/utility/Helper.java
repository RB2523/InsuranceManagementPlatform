package com.utility;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.response.MessageResponse;

public class Helper {

	public static ResponseEntity<Object> sendStatus(HttpStatus httpStatus , String message) {
		MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(message);
		return ResponseEntity.status(httpStatus).body(messageResponse);
	}
}
