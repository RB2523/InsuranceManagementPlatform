package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Client;
import com.repository.ClientRepository;
import com.utility.Helper;

import jakarta.validation.Valid;

@RestController
public class ClientController {
	
	@Autowired
	private ClientRepository clientRepository ;
	

	@GetMapping("/api/clients")
	public ResponseEntity<List<Client>> getAllClients() {
		List<Client> list = clientRepository.findAll();
		return ResponseEntity.status(HttpStatus.OK).body(list);		
	}
	
	@GetMapping("/api/clients/{id}")
	public ResponseEntity<Object> getClientById(@PathVariable String id) {
		Optional<Client> client = clientRepository.findById(id) ;
		
		if(client.isEmpty()) {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Client with specified ID did not present");
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(client.get());
		
	}
	
	@PostMapping("/api/clients")
	public ResponseEntity<Client> saveClient(@Valid @RequestBody Client client) {
		 clientRepository.save(client);
		return ResponseEntity.status(HttpStatus.CREATED).body(client);
	}
	
	@PutMapping("/api/clients/{id}")
	public ResponseEntity<Object> updateClient(@Valid @RequestBody Client client , @PathVariable String id) {
		ResponseEntity<Object> response = getClientById(id);
		
		if( response.getStatusCode() == HttpStatus.OK) {
			 Client obj = (Client)response.getBody();
			
			 obj.setId(id);
			 obj.setCity(client.getCity());
			 obj.setState(client.getState());
			 obj.setCountry(client.getCountry());
			 obj.setPincode(client.getPincode());
			 obj.setContactNo(client.getContactNo());
			 obj.setDob(client.getDob());
			 obj.setName(client.getName());
			 clientRepository.save(obj);
			 
			 return ResponseEntity.status(HttpStatus.OK).body(obj); 
		} 
		else  {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Cannot update Client with specified ID did not present");
		}		 		 
		
	}
	
	
	@DeleteMapping("/api/clients/{id}")
	public ResponseEntity<Object> deleteClient(@PathVariable String id) {
		
		Optional<Client> client = clientRepository.findById(id) ;
		
		if(client.isEmpty()) {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Cannot Delete Client with specified ID did not present");
		}
		
		clientRepository.deleteById(id);
		return Helper.sendStatus(HttpStatus.OK , "Successfully Deleted");
	}
}
