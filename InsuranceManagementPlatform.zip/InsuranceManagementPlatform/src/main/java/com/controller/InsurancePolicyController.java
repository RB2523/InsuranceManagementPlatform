
package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.InsurancePolicy;
import com.repository.InsurancePolicyRepository;
import com.utility.Helper;

import jakarta.validation.Valid;

@RestController
public class InsurancePolicyController {
	
	@Autowired
	private InsurancePolicyRepository insurancePolicyRepository ;
	

	@GetMapping("/api/policies")
	public ResponseEntity<List<InsurancePolicy>> getAllInsurancePolicy() {
		List<InsurancePolicy> list = insurancePolicyRepository.findAll();
		return ResponseEntity.status(HttpStatus.OK).body(list);		
	}
	
	@GetMapping("/api/policies/{id}")
	public ResponseEntity<Object> getInsurancePolicyById(@PathVariable String id) {
		Optional<InsurancePolicy> insurancePolicy = insurancePolicyRepository.findById(id) ;
		
		if(insurancePolicy.isEmpty()) {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Policy with specified ID did not present");
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(insurancePolicy.get());
		
	}
	
	@PostMapping("/api/policies")
	public ResponseEntity<InsurancePolicy> saveInsurancePolicy(@Valid @RequestBody InsurancePolicy insurancePolicy) {
		insurancePolicyRepository.save(insurancePolicy);
		return ResponseEntity.status(HttpStatus.CREATED).body(insurancePolicy);
	}
	
	@PutMapping("/api/policies/{id}")
	public ResponseEntity<Object> updateInsurancePolicy(@Valid @RequestBody InsurancePolicy insurancePolicy , @PathVariable String id) {
		ResponseEntity<Object> response = getInsurancePolicyById(id);
		
		if( response.getStatusCode() == HttpStatus.OK) {
			InsurancePolicy obj = (InsurancePolicy)response.getBody();
			
			obj.setPolicyId(id);
			
			obj.setPolicyCoverageAmount(insurancePolicy.getPolicyCoverageAmount());
			obj.setPolicyEndDate(insurancePolicy.getPolicyEndDate());
			obj.setPolicyNumber(insurancePolicy.getPolicyNumber());
			obj.setPolicyPremium(insurancePolicy.getPolicyPremium());
			obj.setPolicyStartDate(insurancePolicy.getPolicyStartDate());
			obj.setPolicyType(insurancePolicy.getPolicyType());
			
			 insurancePolicyRepository.save(obj);
			 
			 return ResponseEntity.status(HttpStatus.OK).body(obj); 
		} 
		else  {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Cannot update Policy with specified ID did not present");
		}		 		 
		
	}
	
	
	@DeleteMapping("/api/policies/{id}")
	public ResponseEntity<Object> deleteInsurancePolicy(@PathVariable String id) {
		
		Optional<InsurancePolicy> insurancePolicy = insurancePolicyRepository.findById(id) ;
		
		if(insurancePolicy.isEmpty()) {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Cannot Delete InsurancePolicy with specified ID did not present");
		}
		
		insurancePolicyRepository.deleteById(id);
		return Helper.sendStatus(HttpStatus.OK , "Successfully Deleted");
	}
}

