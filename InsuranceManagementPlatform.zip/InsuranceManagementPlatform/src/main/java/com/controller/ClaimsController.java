
package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Claims;
import com.repository.ClaimsRepository;
import com.utility.Helper;

import jakarta.validation.Valid;

@RestController
public class ClaimsController {
	
	@Autowired
	private ClaimsRepository claimsRepository ;
	

	@GetMapping("/api/claims")
	public ResponseEntity<List<Claims>> getAllClaims() {
		List<Claims> list = claimsRepository.findAll();
		return ResponseEntity.status(HttpStatus.OK).body(list);		
	}
	
	@GetMapping("/api/claims/{id}")
	public ResponseEntity<Object> getClaimsById(@PathVariable String id) {
		Optional<Claims> claims = claimsRepository.findById(id) ;
		
		if(claims.isEmpty()) {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Claim with specified ID did not present");
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(claims.get());
		
	}
	
	@PostMapping("/api/claims")
	public ResponseEntity<Claims> saveClaim( @Valid @RequestBody Claims claim) {
		claimsRepository.save(claim);
		return ResponseEntity.status(HttpStatus.CREATED).body(claim);
	}
	
	@PutMapping("/api/claims/{id}")
	public ResponseEntity<Object> updateClaim(@Valid @RequestBody Claims claims , @PathVariable String id) {
		ResponseEntity<Object> response = getClaimsById(id);
		
		if( response.getStatusCode() == HttpStatus.OK) {
			Claims obj = (Claims)response.getBody();
			
			obj.setClaimId(id);
			
			obj.setClaimDate(claims.getClaimDate());
			obj.setClaimNumber(claims.getClaimNumber());
			obj.setClaimStatus(claims.getClaimStatus());
			
			claimsRepository.save(obj);
			 
			 return ResponseEntity.status(HttpStatus.OK).body(obj); 
		} 
		else  {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Cannot update Claim with specified ID did not present");
		}		 		 
		
	}
	
	
	@DeleteMapping("/api/claims/{id}")
	public ResponseEntity<Object> deleteClaim(@PathVariable String id) {
		
		Optional<Claims> claim = claimsRepository.findById(id) ;
		
		if(claim.isEmpty()) {
			return Helper.sendStatus(HttpStatus.BAD_REQUEST , "Cannot Delete Claim with specified ID did not present");
		}
		
		claimsRepository.deleteById(id);
		return Helper.sendStatus(HttpStatus.OK , "Successfully Deleted");
	}
}



