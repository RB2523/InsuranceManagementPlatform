package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.InsurancePolicy;

public interface InsurancePolicyRepository extends JpaRepository<InsurancePolicy, String> {

}
