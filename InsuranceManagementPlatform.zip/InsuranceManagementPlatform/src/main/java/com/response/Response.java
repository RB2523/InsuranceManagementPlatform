package com.response;

public interface Response {

}
