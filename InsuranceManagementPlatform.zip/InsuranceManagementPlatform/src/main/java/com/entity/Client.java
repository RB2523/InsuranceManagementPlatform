package com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="client")
public class Client {
	
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name ="client_id")
	private String id;
	
	@Column(name = "client_name")
	@Pattern(regexp ="[a-zA-Z\\s]+" , message = "name can have only lower and upper case alphabets")
	@NotBlank(message = "name is mandatory")
	private String name;
	
	@Column(name = "client_dob")
	private String dob;
	
	@Column(name ="client_city")
	@Pattern(regexp ="[a-zA-Z\\s]+" , message = "city can have only lower and upper case alphabets")
	@NotBlank(message = "city is mandatory")
	private String city ;
	
	@Column(name ="client_state")
	@Pattern(regexp ="[a-zA-Z\\s]+" , message = "state can have only lower and upper case alphabets")
	@NotBlank(message = "state is mandatory")
	private String state;
	
	@Column(name ="client_pincode")
	@Pattern(regexp ="^[0-9]+$"  , message = "pincode can have only numbers")
	@NotBlank(message = "pincode is mandatory")
	private String pincode;
	
	@Column(name ="client_country")
	@Pattern(regexp ="[a-zA-Z\\s]+" , message = "country can have only lower and upper case alphabets")
	@NotBlank(message = "country is mandatory")
	private String country;

	@Column(name = "client_contactNO")
	@NotBlank(message = "contactNo is mandatory")
	@Pattern(regexp ="^[0-9]+$" , message = "contactNo can have only have numbers")
	@Size(min = 10 ,max =10 , message="contactNo must have 10 digits")
	private String contactNo ;
	
//	@JoinColumn(name = "insurance_policy_list")
//	@ManyToMany
//	private List<InsurancePolicy> insurancePolicyList ;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}	
	
	
}
