package com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name="claims")
public class Claims {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name ="claim_id")
	private String claimId;
	
	@Column(name ="claim_number")
	@NotBlank(message = "claimNumber is mandatory")
	@Pattern(regexp ="^[0-9]+$"  , message = "claimNumber can have only numbers")
	private String claimNumber;
	
	@Column(name ="claim_date")
	@NotBlank(message = "claimDate is mandatory")
	private String claimDate ;
	
	@Column(name ="claim_status")
	@NotBlank(message = "claimStatus is mandatory")
	@Pattern(regexp ="[a-zA-Z\\s]+" , message = "claimStatus can have only lower and upper case alphabets")
	private String claimStatus;
	
//	@JoinColumn(name = "insurance_policy_id")
//	@ManyToOne
//	private InsurancePolicy insurancePolicy;


	public String getClaimId() {
		return claimId;
	}

	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(String claimDate) {
		this.claimDate = claimDate;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	
}
