package com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;


@Entity
@Table(name="InsurancePolicy")
public class InsurancePolicy {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name ="policy_id")
	private String policyId;
	
	@Column(name ="policy_number")
	@NotBlank(message = "policyNumber is mandatory")
	private String policyNumber;
	
	@Column(name ="policy_type")
	@NotBlank(message = "policyType is mandatory")
	private String policyType;
	
	@Column(name ="policy_coverage_amount")
	@NotBlank(message = "policyCoverageAmount is mandatory")
	@Pattern(regexp ="^[0-9]+$"  , message = "policyCoverageAmount can have only numbers")
	private String policyCoverageAmount ;
	
	@Column(name ="policy_premium")
	@NotBlank(message = "policyPremium is mandatory")
	@Pattern(regexp ="^[0-9]+$"  , message = "policyPremium can have only numbers")
	private String policyPremium ;
	
	@Column(name ="policy_start_date")
	@NotBlank(message = "policyStartDate is mandatory")
	private String policyStartDate;
	
	@Column(name ="policy_end_date")
	@NotBlank(message = "policyEndDate is mandatory")
	private String policyEndDate ;
	
//	@ManyToMany(mappedBy = "insurancePolicyList" ,cascade = CascadeType.ALL)
//	private List<Client> clientList;
//	
//	@OneToMany(mappedBy = "insurancePolicy")
//	private List<Claims> claimsList;


	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public String getPolicyCoverageAmount() {
		return policyCoverageAmount;
	}

	public void setPolicyCoverageAmount(String policyCoverageAmount) {
		this.policyCoverageAmount = policyCoverageAmount;
	}

	public String getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(String policyPremium) {
		this.policyPremium = policyPremium;
	}

	public String getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(String policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public String getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(String policyEndDate) {
		this.policyEndDate = policyEndDate;
	}
	
	
}
