package com.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.response.MessageResponse;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	
	
	public ResponseEntity<Object> responseTemplate1() {
		MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage("Some Internal Error occurred Please try after some time");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(messageResponse);
	}
	
	public ResponseEntity<Object> responseTemplateBodyMissing() {
		MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage("Body Missing");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(messageResponse);
	}
	
	
	
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<Object> resolveBodyMissingException(HttpMessageNotReadableException e) {
		e.printStackTrace();
		return responseTemplateBodyMissing();
	}
	
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,String>> validateFields(MethodArgumentNotValidException e) {
		e.printStackTrace();
		Map<String,String> map = new HashMap<>();
		e.getBindingResult().getAllErrors().forEach( (error) -> {
			String fieldName = ((FieldError) error).getField();
			String message = error.getDefaultMessage();
			map.put(fieldName, message);
		});
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(map);
	}
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> resolveException(Exception e) {
		e.printStackTrace();
		System.out.println("Running...");
		return responseTemplate1();
	}
}
